var a = new sound("audio/a3.mp3", false);
var b = new sound("audio/b3.mp3", false);
var c = new sound("audio/c3.mp3", false);
var d = new sound("audio/d3.mp3", false);
var e = new sound("audio/e3.mp3", false);
var f = new sound("audio/f3.mp3", false);
var g = new sound("audio/g3.mp3", false);
var muted = false;
var Timer;
ShowHello();
var mazeTimer = document.getElementById("maze_timer");

function muteMe(elem, mute) {
    elem.muted = mute;
}

function mute() {
    if (muted) {
        muted = false
        document.getElementsByTagName("audio").muted = false;
        var elems = document.querySelectorAll("audio");
        [].forEach.call(elems, function(elem) {
            muteMe(elem, false);
        });
        document.getElementById("soundB").style.backgroundImage = "url('img/soundOK.png')";
    } else {
        muted = true
        document.getElementsByTagName("audio").muted = true;
        var elems = document.querySelectorAll("audio");
        [].forEach.call(elems, function(elem) {
            muteMe(elem, true);
        });
        document.getElementById("soundB").style.backgroundImage = "url('img/soundNO.png')";
    }
}

function startGame() {
    drawIt();
}

function ShowHello() {
    const href = $(this).attr('href')
    Swal.fire({
        title: "<h5>WELCOME TO THE NOTE BLOCKS</h5>",
        text: "What you need to do is simple. Destroy all blocks, for every block you destroy, it will play a different sound. Once you destroy all blocks, a melody will play based on the blocks you destroyed. I hope you are talented in music. Are you ready?",
        confirmButtonText: "Let's play!",
        confirmButtonColor: 'yellow',
    }).then((result) => {
        startGame();
    })
}

function endGame() {
    clearInterval(Timer);
}

function regenerate() {
    now = 0;
    mazeTimer.innerHTML = "Time: 0m 0s";
    startGame();
}
$(".swal2-modal").css('background', 'transparent');
$(".swal2-html-container").css('font-family', 'cursive');
$(".swal2-title").css('color', 'white');
$(".swal2-content").css('color', 'white');
$(".swal2-confirm").css('background', 'transparent');
$(".swal2-confirm").css('border', 'white 1px solid');
$(".swal2-confirm").css('font-weight', '600');

function sound(src, loop) {
    this.sound = document.createElement("audio");
    this.sound.src = src;
    this.sound.setAttribute("preload", "auto");
    this.sound.setAttribute("controls", "none");
    this.sound.style.display = "none";
    this.sound.setAttribute("allow", "autoplay");
    if (loop)
        this.sound.setAttribute("loop", "loop");
    document.body.appendChild(this.sound);
    this.play = function() {
        this.sound.play();
    }
    this.stop = function() {
        this.sound.pause();
    }
}

function drawIt() {
    var x = 300;
    var y = 630;
    var dx = 6;
    var dy = -10;
    var WIDTH;
    var HEIGHT;
    var r = 10;
    var ctx;
    var bricks;
    var NROWS;
    var NCOLS;
    var BRICKWIDTH;
    var BRICKHEIGHT;
    var PADDING;
    var tocke;
    var now = 0;
    var inter;
    var paddlex;
    var paddleh;
    var paddlew;
    var canvasMinX;
    var canvasMaxX;
    var target = 0;
    var colors = ["", "white", "orange", "yellow", "dodgerblue", "violet", "lightgreen"];
    init();

    function initbricks() {
        NROWS = 6;
        NCOLS = 7;
        BRICKWIDTH = (WIDTH / NCOLS) - 1;
        BRICKHEIGHT = 25;
        PADDING = 1;
        // bricks = new Array(NROWS);
        // for (i = 0; i < NROWS; i++) {
        //     bricks[i] = new Array(NCOLS);
        //     for (j = 0; j < NCOLS; j++) {
        //         bricks[i][j] = 1;
        //     }
        // }
        // bricks = [
        //     [1, 1, 1, 1, 1, 1, 1],
        //     [1, 0, 0, 0, 1, 1, 1],
        //     [1, 0, 0, 0, 1, 1, 1],
        //     [1, 0, 0, 0, 1, 1, 1],
        //     [1, 0, 0, 0, 1, 1, 1],
        //     [1, 0, 1, 1, 1, 1, 1]
        // ];
        bricks = [
            [1, 2, 3, 4, 5, 6, 1],
            [1, 1, 1, 1, 0, 1, 1],
            [1, 1, 1, 1, 1, 1, 1],
            [1, 1, 1, 1, 1, 1, 1],
            [1, 1, 1, 1, 1, 1, 1],
            [1, 1, 1, 1, 1, 1, 1]
        ];
    }

    function init() {
        ctx = $('#canvas')[0].getContext("2d");
        WIDTH = $("#canvas").width();
        HEIGHT = $("#canvas").height();
        initbricks();
        tocke = 0;
        $("#tocke").html(tocke);
        Timer = setInterval(timer1, 1000);
        inter = setInterval(draw, 15);
        for (i = 0; i < NROWS; i++) {
            for (j = 0; j < NCOLS; j++) {
                target += bricks[i][j];
            }
        }
    }

    function timer1() {
        now++;
        var minutes = Math.floor(now / 60);
        var seconds = Math.floor(now % 60);
        mazeTimer.innerHTML = "Time: " + minutes + "m " + seconds + "s";
    }

    function circle(x, y, r) {
        ctx.beginPath();
        ctx.fillStyle = "rgb(255, 255, 0)"
        ctx.arc(x, y, r, 0, Math.PI * 2, true);
        ctx.closePath();
        ctx.fill();
    }

    function rect(x, y, w, h, color) {
        ctx.beginPath();
        ctx.fillStyle = colors[color];
        ctx.rect(x, y, w, h);
        ctx.closePath();
        ctx.fill();
    }

    function clear() {
        ctx.clearRect(0, 0, WIDTH, HEIGHT);
    }

    function init_mouse() {
        //canvasMinX = $("#canvas").offset().left;
        canvasMinX = $("canvas").offset().left;
        canvasMaxX = canvasMinX + WIDTH;
    }

    function onMouseMove(evt) {
        if (evt.pageX > canvasMinX && evt.pageX < canvasMaxX - paddlew) {
            paddlex = evt.pageX - canvasMinX;
        }
    }
    $(document).mousemove(onMouseMove);


    init_mouse();

    function init_paddle() {
        paddlex = WIDTH / 2;
        paddleh = 10;
        paddlew = 100;
    }
    init_paddle();
    var rightDown = false;
    var leftDown = false;

    //nastavljanje leve in desne tipke
    function onKeyDown(evt) {
        if (evt.keyCode == 39)
            rightDown = true;
        else if (evt.keyCode == 37) leftDown = true;
    }

    function onKeyUp(evt) {
        if (evt.keyCode == 39)
            rightDown = false;
        else if (evt.keyCode == 37) leftDown = false;
    }
    $(document).keydown(onKeyDown);
    $(document).keyup(onKeyUp);

    function draw() {
        clear();
        circle(x, y, 10);
        if (rightDown) {
            if ((paddlex + paddlew) < WIDTH) {
                paddlex += 10;
            } else {
                paddlex = WIDTH - paddlew;
            }
        } else if (leftDown) {
            if (paddlex > 0) {
                paddlex -= 10;
            } else {
                paddlex = 0;
            }
        }
        rect(paddlex, HEIGHT - paddleh, paddlew, paddleh);

        for (i = 0; i < NROWS; i++) {
            for (j = 0; j < NCOLS; j++) {
                if (bricks[i][j] != 0) {
                    rect((j * (BRICKWIDTH + PADDING)) + PADDING,
                        (i * (BRICKHEIGHT + PADDING)) + PADDING,
                        BRICKWIDTH, BRICKHEIGHT, bricks[i][j]);
                }
            }
        }

        rowheight = BRICKHEIGHT + PADDING + paddleh / 2;
        colwidth = BRICKWIDTH + PADDING + paddleh / 2;
        try {
            if (y < NROWS * rowheight - (dy < 0 ? dy : -dy)) {
                row = Math.floor((y - rowheight / 2) / rowheight);
                col = Math.floor((x + r) / colwidth);
                //Spodnji odboj
                if (row >= 0 && col >= 0 && bricks[row][col] != 0) {
                    dy = -dy;
                    hit(row, col)
                } else {
                    row = Math.floor((y + rowheight + r) / rowheight);
                    //Zgornji odboj
                    if (row >= 0 && col >= 0 && bricks[row][col] != 0) {
                        dy = -dy;
                        hit(row, col)
                    } else {
                        row = Math.floor((y + r) / rowheight);
                        col = Math.floor((x - r) / colwidth);
                        //Desni odboj
                        if (row >= 0 && col >= 0 && bricks[row][col] != 0) {
                            dx = -dx;
                            hit(row, col)
                        } else {
                            col = Math.floor((x + colwidth / 2 - r) / colwidth);
                            //Levi odboj
                            if (row >= 0 && col >= 0 && bricks[row][col] != 0) {
                                dx = -dx;
                                hit(row, col)
                            }
                        }
                    }
                }
            }
        } catch (error) {
            console.log(error);
        }
        if (x + dx > WIDTH - r || x + dx < 0 + r)
            dx = -dx;
        if (y + dy < 0 + r)
            dy = -dy;
        else if (y + dy > HEIGHT - r - paddleh) {
            if (x > paddlex && x < paddlex + paddlew) {
                dx = 8 * ((x - (paddlex + paddlew / 2)) / paddlew);
                dy = -dy;
            } else if (y + dy > HEIGHT - r) {
                clearInterval(inter);
                clearInterval(Timer);
            }
        }
        x += dx;
        y += dy;
    }

    function hit(i, j) {
        bricks[i][j] -= 1;
        tocke += 1;
        $("#tocke").html(tocke);
        console.log("3");
        if (target == tocke) {
            console.log("finish");
        }
    }
}